package com.zynova.mafia

import android.app.Activity
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.widget.*
import java.util.*

private enum class Team { CITY, MAFIA, INDEPENDENT }
private enum class Role(val title:String,val team:Team,val max:Int=1){
    CITIZEN("شهروند ساده",Team.CITY,20), DETECTIVE("کارآگاه",Team.CITY), DOCTOR("دکتر",Team.CITY), PROFESSIONAL("حرفه‌ای",Team.CITY), PRIEST("کشیش",Team.CITY), SHOOTER("تیرانداز",Team.CITY), ARMORED("زره‌پوش",Team.CITY), BLACKSMITH("آهنگر",Team.CITY), FREEMASON("فراماسون",Team.CITY,2), PAOLO("پائولو",Team.CITY), CITIZEN_KANE("همشهری کین",Team.CITY), CONSTANTINE("کنستانتین",Team.CITY),
    GODFATHER("پدرخوانده",Team.MAFIA), MAFIA("مافیای ساده",Team.MAFIA,20), BLOGGER("بلاگر",Team.MAFIA), TERRORIST("تروریست",Team.MAFIA), NATASHA("ناتاشا",Team.MAFIA), CHARLATAN("شارلاتان",Team.MAFIA), GOODMAN("گودمن",Team.MAFIA), JACQUES("جاکوس",Team.MAFIA), LECTER("دکتر لکتر",Team.MAFIA),
    SHERLOCK("شرلوک",Team.INDEPENDENT), KILLER("قاتل",Team.INDEPENDENT), JOKER("جوکر",Team.INDEPENDENT)
}

data class Player(val id:Int,val name:String,var role:Role,var alive:Boolean=true,var protectedTonight:Boolean=false,var silenced:Boolean=false)

class MainActivity: Activity(){
    private lateinit var game:MafiaGame
    override fun onCreate(b:Bundle?){
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,WindowManager.LayoutParams.FLAG_FULLSCREEN)
        game=MafiaGame(this)
        setContentView(game.view())
    }
    override fun onDestroy(){
        if(::game.isInitialized) game.close()
        super.onDestroy()
    }
}

class MafiaGame(private val a:Activity){
    private var voiceEnabled=true
    private var ttsReady=false
    private var narrator:TextToSpeech?=null
    private var lastNarrationKey=""
    private val gold=Color.rgb(220,185,72); private val cyan=Color.rgb(54,191,218); private val red=Color.rgb(190,54,62); private val bg=Color.rgb(7,10,14)
    private var screen=0; private var playerCount=8; private val counts=EnumMap<Role,Int>(Role::class.java); private val players=mutableListOf<Player>()
    private var passIndex=0; private var night=0; private var message=""; private var selected=-1; private var actionRole:Role?=null
    private var voteMap=mutableMapOf<Int,Int>(); private var pendingDeaths=mutableSetOf<Int>(); private var winner:String?=null
    private val root=FrameLayout(a); private val scroll=ScrollView(a); private val box=LinearLayout(a)
    init{
        Role.values().forEach{counts[it]=0}
        counts[Role.CITIZEN]=2; counts[Role.MAFIA]=2; counts[Role.GODFATHER]=1; counts[Role.DOCTOR]=1; counts[Role.DETECTIVE]=1
        narrator=TextToSpeech(a){status->
            if(status==TextToSpeech.SUCCESS){
                val n=narrator
                if(n!=null){
                    val result=n.setLanguage(Locale("fa","IR"))
                    ttsReady=result!=TextToSpeech.LANG_MISSING_DATA && result!=TextToSpeech.LANG_NOT_SUPPORTED
                    n.setSpeechRate(0.92f)
                    n.setPitch(1.0f)
                }
            }
        }
    }
    fun view():View{render();return root}
    fun close(){narrator?.stop();narrator?.shutdown();narrator=null}
    private fun speak(text:String){
        if(!voiceEnabled || !ttsReady || text.isBlank()) return
        narrator?.speak(text,TextToSpeech.QUEUE_FLUSH,null,"zynova_${System.currentTimeMillis()}")
    }
    private fun narrationKey():String="${screen}|$night|$passIndex|${actionRole?.name}|$playerCount"
    private fun narrateScreen(){
        val key=narrationKey()
        if(key==lastNarrationKey) return
        lastNarrationKey=key
        when(screen){
            0 -> speak("به بازی زینوا مافیا خوش آمدید. تعداد بازیکنان را انتخاب کنید و سپس نقش ها را مشخص کنید.")
            1 -> speak("صفحه انتخاب نقش ها. تعداد نقش ها باید دقیقاً با تعداد بازیکنان برابر باشد.")
            2 -> if(passIndex<players.size) speak("بازیکن ${passIndex+1}. گوشی را بردارید و فقط نقش خودتان را ببینید.") else speak("توزیع نقش ها تمام شد. برای شروع شب اول آماده شوید.")
            3 -> {
                val r=actionRole
                speak(if(r!=null) "شب ${night}. نقش شما ${r.title} است. ${nightInstruction(r)}" else "شب تمام شد. گوشی را به بازیکن بعدی بدهید.")
            }
            4 -> speak("روز ${night} شروع شد. زمان گفت و گو و بررسی بازی است.")
            5 -> speak("زمان رأی گیری است. هر بازیکن زنده یک رأی ثبت کند.")
            6 -> speak("بازی به پایان رسید. ${winner ?: "نتیجه مشخص شد"}.")
        }
    }
    private fun render(){root.removeAllViews();root.setBackgroundColor(bg); when(screen){0->home();1->roles();2->reveal();3->night();4->day();5->vote();6->result()}; narrateScreen()}
    private fun base(title:String){scroll.removeAllViews();box.orientation=LinearLayout.VERTICAL;box.setPadding(28,22,28,28);scroll.addView(box);root.addView(scroll,FrameLayout.LayoutParams(-1,-1)); addText(title,28,Color.WHITE,true);addText("Zynova Mafia • بازی دورهمی و آفلاین",14,Color.LTGRAY,false)}
    private fun addText(s:String,size:Int,color:Int,bold:Boolean=false){val t=TextView(a);t.text=s;t.textSize=size.toFloat();t.setTextColor(color);t.gravity=Gravity.CENTER; if(bold)t.setTypeface(null,Typeface.BOLD);t.setPadding(8,12,8,12);box.addView(t)}
    private fun btn(s:String,on:()->Unit,col:Int=cyan){val b=Button(a);b.text=s;b.textSize=16f;b.setTextColor(Color.WHITE);b.background=GradientDrawable().apply{cornerRadius=22f;setColor(col)};b.setOnClickListener{on()};box.addView(b,LinearLayout.LayoutParams(-1,62).apply{setMargins(0,7,0,7)})}
    private fun home(){base("ساخت بازی")
        addText("تعداد بازیکنان: $playerCount",22,gold,true)
        val row=LinearLayout(a);row.gravity=Gravity.CENTER
        fun small(s:String,delta:Int){val b=Button(a);b.text=s;b.setOnClickListener{playerCount=(playerCount+delta).coerceIn(4,20);render()};row.addView(b,LinearLayout.LayoutParams(0,60,1f))}
        small("−",-1);small("+",1);box.addView(row)
        addText("این نسخه سناریو ندارد؛ نقش‌ها را خودت با تعداد دلخواه می‌چینی.",15,Color.LTGRAY)
        btn(if(voiceEnabled) "🔊 گرداننده صوتی: روشن" else "🔇 گرداننده صوتی: خاموش"){
            voiceEnabled=!voiceEnabled
            if(voiceEnabled){lastNarrationKey="";speak("گرداننده صوتی فعال شد.")}
            else narrator?.stop()
            render()
        }, if(voiceEnabled) cyan else Color.DKGRAY)
        addText("گرداننده صوتی مراحل شب، روز، رأی‌گیری و دستور هر نقش را با صدای فارسی اعلام می‌کند.",14,Color.LTGRAY)
        btn("انتخاب نقش‌ها →"){screen=1;render()}
    }
    private fun roles(){base("انتخاب نقش‌ها")
        val total=counts.values.sum(); addText("مجموع نقش‌ها: $total / $playerCount",20,if(total==playerCount)Color.GREEN else red,true)
        addText("نقش‌های رایج + نقش‌های موجود در فهرست شما",14,gold)
        listOf(Team.MAFIA to "گروه مافیا",Team.CITY to "گروه شهروند",Team.INDEPENDENT to "مستقل").forEach{(team,title)->
            addText(title,21,gold,true)
            Role.values().filter{it.team==team}.forEach{r->
                val line=LinearLayout(a);line.gravity=Gravity.CENTER_VERTICAL
                val t=TextView(a);t.text=r.title;t.textSize=16f;t.setTextColor(Color.WHITE);t.gravity=Gravity.RIGHT;line.addView(t,LinearLayout.LayoutParams(0,55,1f))
                val minus=Button(a);minus.text="−";minus.setOnClickListener{counts[r]=((counts[r] ?: 0)-1).coerceAtLeast(0);render()};line.addView(minus,LinearLayout.LayoutParams(58,55))
                val n=TextView(a);n.text="${counts[r]}";n.textSize=18f;n.setTextColor(gold);n.gravity=Gravity.CENTER;line.addView(n,LinearLayout.LayoutParams(55,55))
                val plus=Button(a);plus.text="+";plus.setOnClickListener{counts[r]=((counts[r]?:0)+1).coerceAtMost(r.max);render()};line.addView(plus,LinearLayout.LayoutParams(58,55));box.addView(line)
            }
        }
        btn(if(total==playerCount)"توزیع نقش‌ها و شروع بازی" else "اول مجموع نقش‌ها را برابر بازیکنان کن",{startGame()},if(total==playerCount)red:Color.DKGRAY)
        btn(if(voiceEnabled) "🔊 صدای گرداننده روشن" else "🔇 صدای گرداننده خاموش"){
            voiceEnabled=!voiceEnabled
            if(!voiceEnabled) narrator?.stop() else {lastNarrationKey=""}
            render()
        }, if(voiceEnabled) cyan else Color.DKGRAY)
        btn("بازگشت"){screen=0;render()}
    }
    private fun startGame(){if(counts.values.sum()!=playerCount)return;players.clear();var id=1;Role.values().forEach{r->repeat(counts[r]?:0){players.add(Player(id,"بازیکن $id",r));id++}};players.shuffle();passIndex=0;night=0;screen=2;render()}
    private fun reveal(){base("توزیع نقش‌ها")
        addText("دستگاه را به بازیکن بعدی بده. فقط همان بازیکن کارت خودش را ببیند.",15,gold)
        if(passIndex<players.size){val p=players[passIndex];addText("نوبت بازیکن ${passIndex+1}",24,Color.WHITE,true);addText(p.name,20,cyan);btn("نمایش نقش من"){screen=3;actionRole=p.role;render()}}else{btn("شروع شب اول"){night=1;screen=3;render()}}
        addText("${passIndex} / ${players.size} نقش دیده شده",14,Color.LTGRAY)
    }
    private fun night(){base("شب $night")
        val p=players.firstOrNull{it.alive && it.role==actionRole}
        addText("نقش شما: ${actionRole?.title ?: "—"}",23,gold,true)
        addText(nightInstruction(actionRole),16,Color.WHITE)
        val targets=players.filter{it.alive && it.role!=actionRole}
        if(targets.isNotEmpty() && actionRole!=Role.CITIZEN){addText("هدف را انتخاب کن:",16,Color.LTGRAY);targets.forEach{t->btn("${t.id} • ${t.name}"){resolveNight(actionRole!!,t.id)}}}
        btn("بدون اقدام / ادامه"){resolveNight(actionRole ?: Role.CITIZEN,-1)}
    }
    private fun nightInstruction(r:Role?):String=when(r){Role.DETECTIVE->"یک بازیکن را برای استعلام تیم انتخاب کن.";Role.DOCTOR->"یک بازیکن را برای محافظت انتخاب کن.";Role.GODFATHER,Role.MAFIA,Role.BLOGGER,Role.TERRORIST,Role.NATASHA,Role.CHARLATAN,Role.GOODMAN,Role.JACQUES,Role.LECTER,Role.KILLER->"یک هدف را برای اقدام شبانه انتخاب کن. نتیجه به صورت انتزاعی ثبت می‌شود.";Role.SHERLOCK->"یک بازیکن را برای استعلام انتخاب کن.";Role.JOKER->"این نقش هدف شبانه ندارد.";else->"در این شب اقدام ویژه‌ای ندارید."}
    private fun resolveNight(r:Role,target:Int){
        if(r==Role.DETECTIVE && target>0){val p=players[target-1];message="نتیجه استعلام: ${if(p.role.team==Team.MAFIA)"مافیا" else "غیرمافیا"}"}
        if(r==Role.SHERLOCK && target>0){val p=players[target-1];message="شرلوک: نقش ${p.name} در تیم ${teamName(p.role.team)} است."}
        if(r==Role.DOCTOR && target>0){players[target-1].protectedTonight=true;message="محافظت ثبت شد."}
        if(r in setOf(Role.GODFATHER,Role.MAFIA,Role.KILLER) && target>0) pendingDeaths.add(target)
        if(r==Role.BLOGGER && target>0) players[target-1].silenced=true
        actionRole=null;advanceNightActor()
    }
    private fun advanceNightActor(){passIndex++; if(passIndex<players.size){screen=2}else{applyNight();screen=4};render()}
    private fun applyNight(){pendingDeaths.forEach{id->val p=players.getOrNull(id-1);if(p!=null&&p.alive&&!p.protectedTonight){p.alive=false}};players.forEach{it.protectedTonight=false};pendingDeaths.clear();passIndex=0;winner=checkWinner()}
    private fun day(){base("روز $night • گفت‌وگو")
        addText("بازیکنان زنده: ${players.count{it.alive}}",20,gold);players.filter{it.alive}.forEach{p->addText("${p.id} • ${p.name}",17,Color.WHITE)}
        if(message.isNotBlank()){addText(message,16,cyan);message=""}
        btn("رفتن به رأی‌گیری"){screen=5;render()}
    }
    private fun vote(){base("رأی‌گیری روز")
        addText("هر بازیکن زنده یک رأی دارد. رأی‌ها ثبت و بیشترین رأی حذف می‌شود.",15,gold)
        val alive=players.filter{it.alive}; alive.forEach{voter->
            addText("رأی ${voter.name}",17,Color.WHITE);alive.filter{it.id!=voter.id}.forEach{target->btn("→ ${target.name}"){voteMap[voter.id]=target.id;render()}}
            addText(if(voteMap.containsKey(voter.id))"ثبت شد: ${players[voteMap[voter.id]!!-1].name}" else "هنوز رأی نداده",14,Color.LTGRAY)
        }
        if(alive.all{voteMap.containsKey(it.id)})btn("اعمال نتیجه رأی"){applyVote()}
    }
    private fun applyVote(){val countsV=voteMap.values.groupingBy{it}.eachCount();val top=countsV.maxByOrNull{it.value};if(top!=null){players[top.key-1].alive=false;message="در رأی‌گیری، ${players[top.key-1].name} از بازی خارج شد."};voteMap.clear();winner=checkWinner();if(winner!=null)screen=6 else{night++;passIndex=0;screen=2};render()}
    private fun checkWinner():String?{val mafia=players.count{it.alive&&it.role.team==Team.MAFIA};val city=players.count{it.alive&&it.role.team==Team.CITY};val ind=players.count{it.alive&&it.role.team==Team.INDEPENDENT};if(mafia==0&&ind==0)return"شهروندان برنده شدند";if(mafia>=city+ind&&mafia>0)return"مافیا برنده شد";if(ind==1&&mafia==0&&city==1)return"مستقل برنده شد";return null}
    private fun result(){base("پایان بازی");addText(winner ?: "بازی تمام شد",30,gold,true);addText("نقش‌ها",20,Color.WHITE,true);players.forEach{addText("${it.name}: ${it.role.title} — ${if(it.alive)"زنده" else "خارج شده"}",15,if(it.alive)Color.WHITE:Color.GRAY)};btn("بازی دوباره"){Role.values().forEach{counts[it]=0};counts[Role.CITIZEN]=2;counts[Role.MAFIA]=2;counts[Role.GODFATHER]=1;counts[Role.DOCTOR]=1;counts[Role.DETECTIVE]=1;playerCount=8;screen=0;render()}}
    private fun teamName(t:Team)=when(t){Team.CITY->"شهروند";Team.MAFIA->"مافیا";Team.INDEPENDENT->"مستقل"}
}
