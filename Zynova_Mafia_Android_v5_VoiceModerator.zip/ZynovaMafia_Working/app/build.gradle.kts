plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android { namespace = "com.zynova.mafia"; compileSdk = 35
    defaultConfig { applicationId = "com.zynova.mafia"; minSdk = 24; targetSdk = 35; versionCode = 5; versionName = "5.0" }
}
